// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

import java.util.Comparator;

// Referenced classes of package net.minecraft.src:
//            WorldRenderer, Entity

public class EntitySorter
    implements Comparator
{

    public EntitySorter(Entity entity)
    {
        entityForSorting = entity;
    }

    public int sortByDistanceToEntity(WorldRenderer worldrenderer, WorldRenderer worldrenderer1)
    {
        return worldrenderer.distanceToEntitySquared(entityForSorting) >= worldrenderer1.distanceToEntitySquared(entityForSorting) ? 1 : -1;
    }

    public int compare(Object obj, Object obj1)
    {
        return sortByDistanceToEntity((WorldRenderer)obj, (WorldRenderer)obj1);
    }

    private Entity entityForSorting;
}
