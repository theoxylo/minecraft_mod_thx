// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;


public interface J_JsonListener
{

    public abstract void func_27195_b();

    public abstract void func_27204_c();

    public abstract void func_27200_d();

    public abstract void func_27197_e();

    public abstract void func_27194_f();

    public abstract void func_27203_g();

    public abstract void func_27205_a(String s);

    public abstract void func_27199_h();

    public abstract void func_27198_c(String s);

    public abstract void func_27201_b(String s);

    public abstract void func_27196_i();

    public abstract void func_27193_j();

    public abstract void func_27202_k();
}
