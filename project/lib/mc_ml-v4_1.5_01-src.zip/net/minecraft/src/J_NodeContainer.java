// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;


// Referenced classes of package net.minecraft.src:
//            J_JsonListenerToJdomAdapter, J_JsonNodeBuilder, J_JsonFieldBuilder

interface J_NodeContainer
{

    public abstract void func_27290_a(J_JsonNodeBuilder j_jsonnodebuilder);

    public abstract void func_27289_a(J_JsonFieldBuilder j_jsonfieldbuilder);
}
